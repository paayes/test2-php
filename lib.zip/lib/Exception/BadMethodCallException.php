<?php

namespace Paayes\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
