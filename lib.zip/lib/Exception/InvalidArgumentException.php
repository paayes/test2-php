<?php

namespace Paayes\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
