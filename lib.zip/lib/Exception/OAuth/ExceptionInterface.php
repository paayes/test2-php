<?php

namespace Paayes\Exception\OAuth;

/**
 * The base interface for all Paayes OAuth exceptions.
 */
interface ExceptionInterface extends \Paayes\Exception\ExceptionInterface
{
}
