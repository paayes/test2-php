<?php

namespace Paayes\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
